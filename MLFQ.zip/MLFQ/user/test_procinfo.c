
#include "user.h"  // For procinfo definition

void print_procinfo(struct procinfo *info) {
    printf("Process Information:\n");
    printf("  PID: %d\n", info->pid);
    printf("  Name: %s\n", info->name);
    printf("  State: %d\n", info->state);
    printf("  Creation Time: %d ticks\n", info->creation_time);
    printf("  Total CPU Ticks: %d\n", info->total_cpu_ticks);
    printf("  Times Scheduled: %d\n", info->times_scheduled);
    printf("  CPU Utilization: %.2f%%\n", 
           (info->total_cpu_ticks * 100.0) / (uptime() - info->creation_time));
}

int main(int argc, char *argv[]) {
    struct procinfo info;
    int pid;
    
    if(argc < 2) {
        // Test with current process
        pid = getpid();
        printf("Testing getprocinfo with current process (PID: %d)\n", pid);
    } else {
        pid = atoi(argv[1]);
    }
    
    if(getprocinfo(pid, &info) == 0) {
        print_procinfo(&info);
    } else {
        printf("Error: Could not get process information for PID %d\n", pid);
        exit(1);
    }
    
    exit(0);
}
