#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("=== System Call Verification for CLO2 Project ===\n");
    
    struct procinfo info;  // Add this line to store the results
    
    // Test 1: Basic functionality
    printf("1. Testing getprocinfo with current process...\n");
    int result = getprocinfo(getpid(), &info);  // Add second argument
    printf("   Result: %d (%s)\n", result, result == 0 ? "PASS" : "FAIL");
    
    if(result == 0) {
        printf("   Process Info: PID=%d, Name=%s, CPU Ticks=%d, Scheduled=%d times\n", 
               info.pid, info.name, info.total_cpu_ticks, info.times_scheduled);
    }
    
    // Test 2: Error handling
    printf("2. Testing error handling...\n");
    result = getprocinfo(9999, &info); // Invalid PID - add second argument
    printf("   Result: %d (%s)\n", result, result == -1 ? "PASS" : "FAIL");
    
    // Test 3: Process range
    printf("3. Testing with different PIDs...\n");
    for(int pid = 1; pid <= 3; pid++) {
        result = getprocinfo(pid, &info);  // Add second argument
        printf("   PID %d: %s", pid, result == 0 ? "Accessible" : "Inaccessible");
        
        if(result == 0) {
            printf(" - %s (CPU: %d ticks)", info.name, info.total_cpu_ticks);
        }
        printf("\n");
    }
    
    printf("=== Initial Verification Complete ===\n");
    exit(0);
}
