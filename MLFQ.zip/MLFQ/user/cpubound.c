#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("CPU-bound process started (PID: %d)\n", getpid());        
    printf("-------------------------------------------------------------\n");
    // Get initial process info
    struct procinfo info_start, info_end;
    if (getprocinfo(getpid(), &info_start) == 0) {
        printf("Initial - CPU Ticks: %d, Times Scheduled: %d\n", 
               info_start.total_cpu_ticks, info_start.times_scheduled);
    }    
    printf("-------------------------------------------------------------\n");
    // Heavy computational load - calculating primes
    int prime_count = 0;
    for (long long n = 2; n <= 50000; n++) {
        int is_prime = 1;
        for (long long i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                is_prime = 0;
                break;
            }
        }

        if (is_prime) {
            prime_count++;
        }
        
        if (n % 10000 == 0 || n == 50000) {
            struct procinfo current_info;
            if (getprocinfo(getpid(), &current_info) == 0) {
                printf("Progress %lld/50000 - CPU Ticks: %d, Scheduled: %d times\n", 
                       n, current_info.total_cpu_ticks, current_info.times_scheduled);
            }
            if(n == 50000){
               printf("Primes calculated in - CPU Ticks: %d, Times Scheduled: %d\n", 
               current_info.total_cpu_ticks - info_start.total_cpu_ticks, current_info.times_scheduled - info_start.times_scheduled);
            }
        }
    }
    printf("-------------------------------------------------------------\n");
    getprocinfo(getpid(), &info_end);
    printf("Total CPU consumption: %d ticks\n", info_end.total_cpu_ticks);
    printf("Times scheduled during computation: %d\n", info_end.times_scheduled);    
    printf("-------------------------------------------------------------\n");

    exit(0);
    return 0;
}
