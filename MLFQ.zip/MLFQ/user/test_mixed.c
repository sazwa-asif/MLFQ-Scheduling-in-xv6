#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("=== Testing MIXED workload with Round Robin ===\n");
    printf("Running CPU-bound and I/O-bound processes simultaneously\n\n");
    
    int start_time = uptime();
    
    int cpu_pid = fork();
    if(cpu_pid == 0) {
        char *argv[] = {"cpubound", 0};
        exec("cpubound", argv);
        exit(0);
    }
    
    int io_pid = fork();
    if(io_pid == 0) {
        char *argv[] = {"iobound", 0};
        exec("iobound", argv);
        exit(0);
    }
    
    // Wait for both processes
    wait(0);
    wait(0);
    
    int end_time = uptime();
    
    printf("\n=== Mixed Workload Results ===\n");
    printf("Total test duration: %d ticks\n", end_time - start_time);
    
    // Collect final statistics
    struct procinfo cpu_info, io_info;
    
    if(getprocinfo(cpu_pid, &cpu_info) == 0) {
        printf("CPU-bound final: %d CPU ticks, %d schedules\n", 
               cpu_info.total_cpu_ticks, cpu_info.times_scheduled);
    }
    
    if(getprocinfo(io_pid, &io_info) == 0) {
        printf("I/O-bound final: %d CPU ticks, %d schedules\n", 
               io_info.total_cpu_ticks, io_info.times_scheduled);
    }
    
    printf("\n=== Round Robin Baseline Established ===\n");
    
    exit(0);
}
