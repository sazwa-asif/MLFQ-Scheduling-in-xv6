#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"

int main() {
    printf("I/O-bound process started (PID: %d)\n", getpid());
    printf("-------------------------------------------------------------\n");

    // Get initial process info
    struct procinfo info_start, info_end;
    if(getprocinfo(getpid(), &info_start) == 0) {
        printf("Initial - CPU Ticks: %d, Times Scheduled: %d\n", 
               info_start.total_cpu_ticks, info_start.times_scheduled);
    }
    printf("-------------------------------------------------------------\n");

    // Open file once at the beginning
    int fd = open("iotest", O_CREATE | O_WRONLY);
    if(fd < 0) {
        printf("Failed to open file\n");
        exit(1);
    }
    
    for(int i = 0; i <= 100; i++) {
        // Single write operation per "I/O operation"
        write(fd, "x", 1);
        
        if(i % 10 == 0) {
            struct procinfo current_info;
            if(getprocinfo(getpid(), &current_info) == 0) {
                printf("I/O-bound: Completed %d/100 operations - CPU Ticks: %d, Scheduled: %d times\n", 
                       i, current_info.total_cpu_ticks, current_info.times_scheduled);
            }
            if(i == 100){
               printf("IO done in - CPU Ticks: %d, Times Scheduled: %d\n", 
               current_info.total_cpu_ticks - info_start.total_cpu_ticks, current_info.times_scheduled - info_start.times_scheduled);
            }
        }
    }
    
    close(fd);
    
    printf("-------------------------------------------------------------\n");
    getprocinfo(getpid(), &info_end);
    printf("Total CPU consumption: %d ticks\n", info_end.total_cpu_ticks);
    printf("Times scheduled during computation: %d\n", info_end.times_scheduled);    
    printf("-------------------------------------------------------------\n");

    exit(0);
}
