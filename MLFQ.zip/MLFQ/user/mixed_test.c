#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("=== Mixed Workload Test - Round Robin Baseline ===\n");
    
    int start_time = uptime();
    
    int cpu_pid = fork();
    if(cpu_pid == 0) {
        // CPU-bound child
        for(long long i = 0; i < 100000000; i++) {
            asm volatile("nop");
        }
        printf("CPU-child finished\n");
        exit(0);
    }
    
    int io_pid = fork();
    if(io_pid == 0) {
        // I/O-bound child
        for(int i = 0; i < 50; i++) {
            sleep(1);
            if(i % 10 == 0) {
                printf("I/O-child: iteration %d/50\n", i);
            }
        }
        printf("I/O-child finished\n");
        exit(0);
    }
    
    // Parent waits for both
    wait(0);
    wait(0);
    
    int end_time = uptime();
    printf("Total test duration: %d ticks\n", end_time - start_time);
    printf("=== Baseline Test Complete ===\n");
    
    exit(0);
}
