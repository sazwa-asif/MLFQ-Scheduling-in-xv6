#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main() {
    printf("=== Testing I/O-bound process with Round Robin ===\n");
    
    int start_time = uptime();
    int pid = fork();
    
    if(pid == 0) {
        // Child process - run I/O-bound
        char *argv[] = {"iobound", 0};
        exec("iobound", argv);
        exit(0);
    } else {
        // Parent process - monitor
        wait(0);
        int end_time = uptime();
        
        printf("\n=== I/O-bound Test Results ===\n");
        printf("Total test duration: %d ticks\n", end_time - start_time);
        
        // Get final stats
        struct procinfo info;
        if(getprocinfo(pid, &info) == 0) {
            printf("Final stats - CPU: %d ticks, Scheduled: %d times\n", 
                   info.total_cpu_ticks, info.times_scheduled);
        }
    }
    
    exit(0);
}
