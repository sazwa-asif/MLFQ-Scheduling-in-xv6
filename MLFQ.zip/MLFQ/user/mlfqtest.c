#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  printf("pid: %d\n", getpid());
  printf("CPU ticks: %d\n", cpu_ticks());
  printf("Times scheduled: %d\n", times_scheduled());
  printf("Queue level: %d\n", queue_level());
  exit(0);
}

