// trap.c (FIXED VERSION)
#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

struct spinlock tickslock;
uint ticks;

extern char trampoline[], uservec[];

// in kernelvec.S, calls kerneltrap().
void kernelvec();

extern int devintr();

void
trapinit(void)
{
  initlock(&tickslock, "time");
}

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
  w_stvec((uint64)kernelvec);
}

//
// handle an interrupt, exception, or system call from user space.
// called from, and returns to, trampoline.S
// return value is user satp for trampoline.S to switch to.
//
uint64
usertrap(void)
{
  int which_dev = 0;

  if((r_sstatus() & SSTATUS_SPP) != 0)
    panic("usertrap: not from user mode");

  // send interrupts and exceptions to kerneltrap(),
  // since we're now in the kernel.
  w_stvec((uint64)kernelvec);

  struct proc *p = myproc();

  // save user program counter.
  p->trapframe->epc = r_sepc();

  if(r_scause() == 8){
    // system call
    if(killed(p))
      kexit(-1);

    // advance past the ecall instruction
    p->trapframe->epc += 4;

    // enable interrupts before syscall
    intr_on();

    syscall();
  } else if((which_dev = devintr()) != 0){
    // device interrupt - let kerneltrap handle timer interrupts
  } else if((r_scause() == 15 || r_scause() == 13) &&
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    // page fault on lazily-allocated page
  } else {
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    setkilled(p);
  }

  if(killed(p))
    kexit(-1);
    
  // CRITICAL FIX: Remove time slice management from usertrap
  // Only track basic CPU usage, let kerneltrap handle MLFQ logic
  if(which_dev == 2) {
    // Just track CPU ticks for accounting
    if(p != 0 && p->state == RUNNING) {
      p->total_cpu_ticks++;
    }
  }

  prepare_return();

  // return the user page table to trampoline.S
  return MAKE_SATP(p->pagetable);
}

//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
  struct proc *p = myproc();

  intr_off(); // no kernel->user traps

  // send traps to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
  w_stvec(trampoline_uservec);

  // set up trapframe values for uservec
  p->trapframe->kernel_satp = r_satp();
  p->trapframe->kernel_sp = p->kstack + PGSIZE;
  p->trapframe->kernel_trap = (uint64)usertrap;
  p->trapframe->kernel_hartid = r_tp();

  // set up registers for sret to user space
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // set SPP=0 for user mode
  x |= SSTATUS_SPIE; // enable interrupts in user mode
  w_sstatus(x);

  w_sepc(p->trapframe->epc);
}

//
// interrupts and exceptions from kernel code
// SINGLE POINT OF TIME SLICE MANAGEMENT
//
void 
kerneltrap()
{
  int which_dev = 0;
  uint64 sepc = r_sepc();
  uint64 sstatus = r_sstatus();
  uint64 scause = r_scause();
  struct proc *p = myproc();

  if((sstatus & SSTATUS_SPP) == 0)
    panic("kerneltrap: not from supervisor mode");
  if(intr_get() != 0)
    panic("kerneltrap: interrupts enabled");

  if((which_dev = devintr()) == 0){
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    panic("kerneltrap");
  }

  // CRITICAL FIX: SINGLE point for MLFQ time slice management
  if(which_dev == 2 && p != 0 && p->state == RUNNING) {
    // Track CPU usage
    p->total_cpu_ticks++;

    // Decrement time slice (ONLY HERE - not in usertrap)
    if(p->time_slice > 0) {
      p->time_slice--;
    }
    
    #ifdef DEBUG_MLFQ
    printf("kerneltrap: pid %d, queue %d, time_slice %d\n", 
           p->pid, p->queue_level, p->time_slice);
    #endif
    
    // Check if time slice expired
    if(p->time_slice <= 0) {
      // Process used full time slice - DEMOTE to lower priority
      if(p->queue_level < NQUEUE - 1) {
        p->queue_level++;
        #ifdef DEBUG_MLFQ
        printf("kerneltrap: pid %d demoted to queue %d\n", p->pid, p->queue_level);
        #endif
      }
      // Reset time slice for new queue level
      // HIGHER priority queues get LONGER time slices
      p->time_slice = TIME_SLICE * (p->queue_level + 1);
      p->boost_eligible = 1;
      
      #ifdef DEBUG_MLFQ
      printf("kerneltrap: pid %d yielding, new time_slice %d\n", p->pid, p->time_slice);
      #endif
      
      // Yield CPU - process used its full time slice
      yield();
    }
  }

  // restore trap registers
  w_sepc(sepc);
  w_sstatus(sstatus);
}

void
clockintr()
{
  if(cpuid() == 0){
    acquire(&tickslock);
    ticks++;
    wakeup(&ticks);
    release(&tickslock);
  }

  // schedule next timer interrupt
  w_stimecmp(r_time() + 1000000);
}

// device interrupt handler
int
devintr()
{
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    // supervisor external interrupt via PLIC
    int irq = plic_claim();

    if(irq == UART0_IRQ){
      uartintr();
    } else if(irq == VIRTIO0_IRQ){
      virtio_disk_intr();
    } else if(irq){
      printf("unexpected interrupt irq=%d\n", irq);
    }

    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    // timer interrupt
    clockintr();
    return 2;
  } else {
    return 0;
  }
}
